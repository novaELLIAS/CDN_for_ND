# DroidNCM
DroidNCM -Android ncm格式转换器


 native code modify from https://github.com/anonymous5l/ncmdump

  NDK r17
  
 # output
 
 文件会产生到/sdcard/Music目录下
  
# bug
请提供ncm地址或者具体的名称
